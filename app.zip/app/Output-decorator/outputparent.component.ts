// outputparent.component.ts

import { Component } from '@angular/core';

@Component({
    selector: 'app-output-parent',
    template: `
    <div>
      <h2>Parent Component</h2>
      <app-output-child (childEvent)="handleChildEvent($event)"></app-output-child>
      
    </div>
  `
})
export class OutputParentComponent {
    handleChildEvent(data: string) {
        console.log('Received from child:', data);
    }
    handleChildEvent1(eventData: string) {
        console.log('Received from child:', eventData);
    }
}

/*

@Output Decorator:

The @Output decorator is used to declare an output property in a child component.
It allows the child component to emit events to the parent component.
To use @Output, import it from @angular/core and apply it to an EventEmitter 
property in the child component class.
*/