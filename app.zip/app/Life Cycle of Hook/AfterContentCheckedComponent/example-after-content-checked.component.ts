import { Component, AfterContentChecked } from '@angular/core';

@Component({
    selector: 'app-example-after-content-checked',
    template: `
    <div>
      <h2>Product Details</h2>
      <p>ID: {{ product.id }}</p>
      <p>Name: {{ product.name }}</p>
      <p>Price: {{ product.price }}</p>
    </div>
  `
})
export class ExampleAfterContentCheckedComponent implements AfterContentChecked {
    product: any; // Assuming 'Product' class or a similar structure

    ngAfterContentChecked(): void {
        // Simulating update logic such as fetching updated product data
        this.product = {
            id: 1,
            name: 'Updated Product',
            price: 129.99
        };
    }
}
