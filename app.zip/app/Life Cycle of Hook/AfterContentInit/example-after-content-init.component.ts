import { Component, AfterContentInit } from '@angular/core';

@Component({
    selector: 'app-example-after-content-init',
    template: `
    <div>
      <h2>Product Details</h2>
      <p>ID: {{ product.id }}</p>
      <p>Name: {{ product.name }}</p>
      <p>Price: {{ product.price }}</p>
    </div>
  `
})
export class ExampleAfterContentInitComponent implements AfterContentInit {
    product: any; // Assuming 'Product' class or a similar structure

    ngAfterContentInit(): void {
        // Simulating initialization logic such as fetching product data
        this.product = {
            id: 1,
            name: 'Example Product',
            price: 99.99
        };
    }
}
