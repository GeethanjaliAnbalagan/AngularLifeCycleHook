import { Component, OnDestroy } from '@angular/core';

@Component({
    selector: 'app-example-on-destroy',
    template: `
    <div>
      <h2>Product Details</h2>
      <p>ID: {{ product.id }}</p>
      <p>Name: {{ product.name }}</p>
      <p>Price: {{ product.price }}</p>
    </div>
  `
})
export class ExampleOnDestroyComponent implements OnDestroy {
    product: any; // Assuming 'Product' class or a similar structure

    constructor() {
        // Simulating initialization logic such as fetching product data
        this.product = {
            id: 1,
            name: 'Example Product',
            price: 99.99
        };
    }

    ngOnDestroy(): void {
        // Perform cleanup tasks here, such as unsubscribing from observables or releasing resources
        console.log('ExampleOnDestroyComponent is destroyed.');
    }
}
