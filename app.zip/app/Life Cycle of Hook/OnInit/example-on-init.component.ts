import { Component, OnInit } from '@angular/core';

@Component({
    selector: 'app-example-on-init',
    template: `
    <p>Product ID: {{ productId }}</p>
    <p>Product Name: {{ productName }}</p>
    <p>Product Price: {{ productPrice }}</p>
  `
})
export class ExampleOnInitComponent implements OnInit {
    productId: number | undefined;
    productName: string | undefined;
    productPrice: number | undefined;

    ngOnInit(): void {
        // Simulating fetching data from a service or initialization logic
        this.productId = 1;
        this.productName = 'Example Product';
        this.productPrice = 100;
    }
}
