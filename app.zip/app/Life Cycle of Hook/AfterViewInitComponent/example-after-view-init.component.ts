import { Component, AfterViewInit } from '@angular/core';

@Component({
    selector: 'app-example-after-view-init',
    template: `
    <div *ngIf="product">
      <h2>Product Details</h2>
      <p>ID: {{ product.id }}</p>
      <p>Name: {{ product.name }}</p>
      <p>Price: {{ product.price }}</p>
    </div>
  `
})
export class ExampleAfterViewInitComponent implements AfterViewInit {
    product: any; // Assuming 'Product' class or a similar structure

    ngAfterViewInit(): void {
        // Simulating initialization logic such as fetching product data after the view is initialized
        this.product = {
            id: 1,
            name: 'Example Product',
            price: 99.99
        };
    }
}
