import { Component, AfterViewChecked } from '@angular/core';

@Component({
    selector: 'app-example-after-view-checked',
    template: `
    <div *ngIf="product">
      <h2>Product Details</h2>
      <p>ID: {{ product.id }}</p>
      <p>Name: {{ product.name }}</p>
      <p>Price: {{ product.price }}</p>
    </div>
  `
})
export class ExampleAfterViewCheckedComponent implements AfterViewChecked {
    product: any; // Assuming 'Product' class or a similar structure

    ngAfterViewChecked(): void {
        // Simulating update logic such as fetching updated product data after the view is checked
        this.product = {
            id: 1,
            name: 'Updated Product',
            price: 129.99
        };
    }
}
