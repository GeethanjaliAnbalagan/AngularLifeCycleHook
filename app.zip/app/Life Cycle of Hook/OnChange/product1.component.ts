import { Component, Input } from '@angular/core';
import { Product1 } from './product1.model';

@Component({
    selector: 'app-product1',
    templateUrl: './product1.component.html',

})
export class Product1Component {
    @Input() product: Product1 | undefined;
}
