import { Directive, Input, OnChanges, SimpleChanges } from '@angular/core';
import { Injectable } from '@angular/core';

@Directive({
    selector: '[exampleOnChanges]'
})
export class ExampleOnChangesDirective implements OnChanges {
    @Input() exampleOnChanges: any;

    ngOnChanges(changes: SimpleChanges): void {
        console.log('Changes detected:', changes);
    }
}
