// example-do-check.component.ts

import { Component, DoCheck, Input } from '@angular/core';
import { Product } from './product.model';

@Component({
    selector: 'app-example-do-check',
    template: `
    <div>
    <div>
    <h2>Product Details</h2>
    <p>ID: {{ product!.id }}</p>
    <p>Name: {{ product!.name }}</p>
    <p>Price: {{ product!.price }}</p>
  </div>
      <p *ngIf="priceChanged">Price Changed!</p>
    </div>
  `
})
export class ExampleDoCheckComponent implements DoCheck {
    @Input() product: Product | undefined; // Declare the product input property
    previousPrice: number | undefined;
    priceChanged: boolean = false;

    ngDoCheck(): void {
        if (this.product && this.product.price !== this.previousPrice) {
            this.previousPrice = this.product.price;
            this.priceChanged = true;
        } else {
            this.priceChanged = false;
        }
    }
}
