import { Component } from '@angular/core';
import { Product } from './Life Cycle of Hook/DoCheck/product.model';
import { Product1 } from './Life Cycle of Hook/OnChange/product1.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  //ngOnChange
  /*
  currentProduct: Product1 = new Product1(1, 'Product 1', 10);

  updateProduct() {
    this.currentProduct = new Product1(2, 'Product 2', 20);
  }
  */

  //ngDoCheck
  //currentProduct: Product = new Product(1, 'Example Product', 99.99);/



}
