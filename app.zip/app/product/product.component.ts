import { Component } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css']
})
export class ProductComponent {

  name: string = "Geetha";
  productName: string = "Product A";
  quantity: number = 10;
  arrivalDate: string = "2022-12-31";
  productDescription: string = "This is good product"
  isOut: boolean = false;
  isError: boolean = true; // Condition for error class
  isRequired: boolean = true; // Condition for required class
  isToday: boolean = new Date().toDateString() === new Date(this.arrivalDate).toDateString(); // Condition for today class
  productCount: number = 0;
  Count() {
    this.productCount++;
  }

  value = "";
  clearValue() {
    this.value = "";
  }

  constructor() { }

  submit(): void {
    console.log("Product Name:", this.productName);
    console.log("Quantity:", this.quantity);
    console.log("Arrival Date:", this.arrivalDate);
  }
}
