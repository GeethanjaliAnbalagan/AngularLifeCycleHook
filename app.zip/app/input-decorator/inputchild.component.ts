// inputchild.component.ts

import { Component, Input } from '@angular/core';

@Component({
    selector: 'app-input-child',
    template: `
    <div>
      <h2>Child Component</h2>
      <p>Received from parent: {{ childProperty }}</p>
    </div>
  `
})
export class InputChildComponent {
    @Input() childProperty: string | undefined;
}
