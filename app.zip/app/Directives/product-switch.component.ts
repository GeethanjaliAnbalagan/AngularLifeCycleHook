// product-switch.component.ts
import { Component } from '@angular/core';

@Component({
    selector: 'app-product-switch',
    templateUrl: './product-switch.component.html',
    styleUrls: ['./product-switch.component.css']
})
export class ProductSwitchComponent {
    selectedProduct: string = 'product1';

    selectProduct(product: string) {
        this.selectedProduct = product;
    }
}
