// product-ng-style.component.ts
import { Component } from '@angular/core';

@Component({
    selector: 'app-product-ng-style',
    templateUrl: './product-ng-style.component.html',
    styleUrls: ['./product-ng-style.component.css']
})
export class ProductNgStyleComponent {
    products: any[] = [
        { name: 'Product 1', price: 10.99, inStock: true },
        { name: 'Product 2', price: 19.99, inStock: false },
        { name: 'Product 3', price: 24.99, inStock: true }
    ];
}
